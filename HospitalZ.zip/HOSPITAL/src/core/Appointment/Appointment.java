/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Appointment;

import core.Persona.Doctor;
import core.Persona.Patient;


/**
 *
 * @author natil
 */
public class Appointment {
    private Doctor doctor;
    private Patient patients;
}
