/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Persona;

import core.Appointment.Appointment;
import core.Hospital.Team;
import core.Hospital.Ward;
import java.util.ArrayList;

/**
 *
 * @author natil
 */
public class Patient {

    private int id;
    private Team team;
    protected ArrayList<Appointment> appointments;
    private Ward ward;
    protected ArrayList<Doctor> doctors;
}
