/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Persona;

import core.Hospital.Team;

/**
 *
 * @author natil
 */
public class ConsultantDoctor extends Doctor{
    private Team LeaderOf;
    
    public ConsultantDoctor (Team LeaderOf, Team team, int id){
        super(team,id);
        this.leaderIfAddTeam(this);
    }
}
