/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Persona;
import core.Hospital.Team;
import core.Appointment.Appointment;
import core.Persona.Patient;
import java.util.ArrayList;
/**
 *
 * @author natil
 */
public abstract class Doctor {
    //id/int
    //team
    //appointment
    //patientes
    protected int id;
    protected Team team;
    protected ArrayList <Appointment> appointments;
    protected ArrayList <Patient> patients;
    
    //contructor es el metodo que crea una clase, simepre publico
    public Doctor (Team team,int id){
        this.id = id;
        this.team = team;        
    }

}   
