/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Hospital;

import core.Persona.ConsultantDoctor;

/**
 *
 * @author natil
 */
public class Team {
    private int id;
    private ConsultantDoctor LeaderOf;    
}
