/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.Hospital;

import core.Persona.Patient;
import java.util.ArrayList;

/**
 *
 * @author natil
 */
public class Ward {
    private int id;
    private ArrayList <Patient> patients;
}
